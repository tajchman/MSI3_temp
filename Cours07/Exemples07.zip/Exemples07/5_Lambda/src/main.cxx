#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "integrale.hxx"

class Foncteur
{
public:
  Foncteur(double a) : p(a){}
  double operator() (double x) const {
    return sin(p*x);
  }
private:
  double p;
};

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  double a = 1.5;
  Foncteur g1(a);
  auto g2 = [=] (double x) { return sin(a*x); };

  std::cout << "(Objet fonction)  intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, g1) << std::endl;

  std::cout << "(Lambda fonction) intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, g2) << std::endl;

  return 0;
}
