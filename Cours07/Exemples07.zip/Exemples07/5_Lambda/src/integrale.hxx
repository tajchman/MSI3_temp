
template <typename T>
double integrale(double a, double b, long n, const T & f)
{
  long i;
  double s = 0;
  double dx = (b-a)/(n-1);

  for (i=0; i<n; i++)
    s += f(a + i*dx);
  s *= dx;

  return s;
}
