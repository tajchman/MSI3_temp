#include <iostream>
#include <cmath>

#include "integrale4.hxx"

int main(int argc, char ** argv)
{
  double a = 1.5, b = 2.0;
  double x0 = 0.0, x1 = 1.0;
  size_t n = 10000000;

  auto f = [a, b](double x) { return sin(a*x + b); };
  auto g = [=](double x) { return cos(a*x); };
  auto h = [&](double x) { return cos(a*x); };
  
  std::cout << "integrale de sin(" << a << " x + " << b << ") entre " 
            << x0 << " et " << x1 
            << " = " << integrale4(x0, x1, n, f) 
            << " exact : " << (cos(a*x0+b) - cos(a*x1+b))/a << std::endl;
  
  std::cout << "integrale de cos(" << a << " x) entre "
            << x0 << " et " << x1 
            << " = " << integrale4(x0, x1, n, g)
            << " exact : " << (sin(a*x1) - sin(a*x0))/a << std::endl;

  a = 2.0;
  std::cout << "integrale de cos(" << a << " x) entre "
            << x0 << " et " << x1 
            << " = " << integrale4(x0, x1, n, g)
            << " exact : " << (sin(a*x1) - sin(a*x0))/a << std::endl;

  
  std::cout << "integrale de cos(" << a << " x) entre "
            << x0 << " et " << x1 
            << " = " << integrale4(x0, x1, n, h)
            << " exact : " << (sin(a*x1) - sin(a*x0))/a << std::endl;

  return 0;
}