#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "foncteurGenerique.hxx"
#include "integrale.hxx"

double f(double x)
{
  return cos(x);
}

class Foncteur1 : public Foncteur
{
public:
  Foncteur1(double a) : p(a){}
  double operator() (double x) const {
    return sin(p*x);
  }
private:
  double p;
};

class Foncteur2 : public Foncteur
{
public:
  Foncteur2(double a, double b) : p(a), q(b) {}
  double operator() (double x) const {
    return sin(p*x) * cos(q*x);
  }
private:
  double p, q;
};

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  Foncteur1 g(1.5);
  Foncteur2 h(2.0,3.0);

  std::cout << "intégrale approchée de cos(x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, f) << std::endl;

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, g) << std::endl;

  std::cout << "intégrale approchée de sin(2x)cos(3x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, h) << std::endl;

  return 0;
}
