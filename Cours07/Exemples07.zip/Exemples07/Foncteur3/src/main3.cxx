#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "foncteur3.hxx"
#include "integrale3.hxx"

double f(double x)
{
  return sin(1.5*x);
}

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  Foncteur3a g1(1.5, sin);
  Foncteur3a g2(1.5, cos);
  Foncteur3b h(3.0, 4.5, sin, cos);

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale3(0.0, 1.0, n, f) << std::endl;

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale3(0.0, 1.0, n, g1) << std::endl;

  std::cout << "intégrale approchée de cos(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale3(0.0, 1.0, n, g2) << std::endl;

  std::cout << "intégrale approchée de sin(3x)*cos(4.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale3(0.0, 1.0, n, h) << std::endl;

  return 0;
}
