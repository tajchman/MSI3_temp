#include "integrale2.hxx"
#include "foncteur2.hxx"

double integrale2(double a, double b, long n, double (*f)(double))
{
  long i;
  double s = 0;
  double dx = (b-a)/(n-1);

  for (i=0; i<n; i++)
    s += f(a + i*dx);
  s *= dx;

  return s;
}

double integrale2(double a, double b, long n, const Foncteur2a & f)
{
  long i;
  double s = 0;
  double dx = (b-a)/(n-1);

  for (i=0; i<n; i++)
    s += f(a + i*dx);
  s *= dx;

  return s;
}

double integrale2(double a, double b, long n, const Foncteur2b & f)
{
  long i;
  double s = 0;
  double dx = (b-a)/(n-1);

  for (i=0; i<n; i++)
    s += f(a + i*dx);
  s *= dx;

  return s;
}

