#ifndef __FONCTEURS2__
#define __FONCTEURS2__

#include <cmath>

class Foncteur2a
{
public:
  Foncteur2a(double p) : _p(p) {}
  double operator() (double x) const {
    return sin(_p * x);
  }

private:
  double _p;
};

class Foncteur2b
{
public:
  Foncteur2b(double p1, double p2): _p1(p1), _p2(p2) {}
  double operator() (double x) const {
    return sin(_p1 * x) * exp(-_p2 *x);
  }
private:
  double _p1, _p2;
};

#endif
