#include <iostream>
#include <cmath>
#include <vector>

#include "genere.hxx"
#include "arguments.hxx"


struct Interpolateur {

  Interpolateur(std::vector<double> &p, std::vector<double> &v) : _p(p), _v(v) {}
  
  double operator()(double x) {
    size_t i, n = _p.size();
    for (i=0; i<n; i++)
      if (_p[i] > x) break;
    if (i == 0)
      return _v[0];
    if (i >= n )
      return _v[n-1];
    double l = (x - _p[i-1])/(_p[i] - _p[i-1]);
    return l*_v[i] + (1-l) *_v[i-1];
  }
  std::vector<double> &_p, &_v;
};

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 400000000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  std::vector<double> pos(n);
  std::vector<double> values(n);
  generePoints(pos, values);

  Interpolateur I(pos, values);

  std::cout << "(Objet fonction)  interpolateur I(0.5) = " << I(0.5) 
            << " (valeur exacte : " << sin(0.5) << ")" << std::endl;

  return 0;
}
