#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "integrale.hxx"

double f(double x)
{
  return 2*x*x;
}

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000000L);
  double a = A.Get("x0", 0.0);
  double b = A.Get("x1", 1.0);

  std::cout << "\nintégrale approchée de 2*x^2 entre " << a << " et " << b << ": " 
            << integrale(a, b, n) << "\n" << std::endl;

  return 0;
}
