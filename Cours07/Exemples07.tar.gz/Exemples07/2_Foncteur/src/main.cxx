#include <iostream>
#include <cmath>

#include "arguments.hxx"
#include "foncteur.hxx"
#include "integrale.hxx"

double f(double x)
{
  return cos(x);
}

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 100000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  Foncteur g(1.5);

  std::cout << "intégrale approchée de cos(x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, f) << std::endl;

  std::cout << "intégrale approchée de sin(1.5x) entre " << x0 << " et " << x1 << ": " 
            << integrale(0.0, 1.0, n, g) << std::endl;

  return 0;
}
