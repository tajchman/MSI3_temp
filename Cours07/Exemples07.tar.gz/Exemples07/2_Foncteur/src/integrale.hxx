
#include "foncteur.hxx"

double integrale(double a, double b, long n, double (*f)(double));

double integrale(double a, double b, long n, const Foncteur & f);
