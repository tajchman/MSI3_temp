#ifndef __FONCTEUR__
#define __FONCTEUR__

#include <cmath>

class Foncteur
{
public:
  Foncteur(double a) : p(a) {}
  double operator() (double x) const {
    return sin(p * x);
  }
private:
  double p;
};


#endif
