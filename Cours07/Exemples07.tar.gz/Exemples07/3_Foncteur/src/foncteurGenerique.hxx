#ifndef __FONCTEURS__
#define __FONCTEURS__

#include <cmath>

class Foncteur
{
public:
  virtual double operator() (double x) const {
    return 0.0;
  }
};

#endif
