
double integrale(double a, double b, long n, double (*f)(double));
