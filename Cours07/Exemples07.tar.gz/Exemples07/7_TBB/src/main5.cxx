#include <iostream>
#include <cmath>
#include "arguments.hxx"
#include "timer.hxx"
#include "tbb/tbb.h"

void Sequentiel(const std::vector<double> &u, 
                std::vector<double> &v,
                double a)
{
    size_t i, n = u.size();
    for (i=0; i<n; i++)
        v[i] = sin(u[i] * a);
}

class ApplyFun {
    const std::vector<double> & _u;
    std::vector<double> & _v;
    double _a;
public:
    void operator()( const tbb::blocked_range<size_t> &r ) const {
        for( size_t i=r.begin(); i!=r.end(); ++i )
            _v[i] = sin(_u[i]*_a);
    }

    ApplyFun( const std::vector<double> &u,  
              std::vector<double> &v, 
              double a ) : _u(u), _v(v), _a(a) {}
};

void Parallel_v1a( const std::vector<double> & u,
                          std::vector<double> & v,
                          double d ) {
    ApplyFun f(u, v, d);
    tbb::parallel_for(tbb::blocked_range<size_t>(0,v.size()), f);
}

void Parallel_v1b( const std::vector<double> & u,
                          std::vector<double> & v,
                          double d ) {
    tbb::parallel_for(tbb::blocked_range<size_t>(0,v.size()), 
                      ApplyFun(u, v, d) );
}


void Parallel_v2( const std::vector<double> & u,
                          std::vector<double> & v,
                          double a ) {
    tbb::parallel_for ( tbb::blocked_range<size_t>(0, u.size()), 
        [&](const tbb::blocked_range<size_t> r) {
            for(size_t i=r.begin(); i<r.end(); ++i)
                v[i] = sin(u[i] * a);
        }
    );
}

void Parallel_v3( std::vector<double> & u,
                          std::vector<double> & v,
                          double a ) {
    tbb::parallel_for ( tbb::blocked_range<size_t>(0, u.size()), 
        [&u, &v, a](const tbb::blocked_range<size_t> r) {
            for(size_t i=r.begin(); i<r.end(); ++i)
                v[i] = sin(u[i] * a);
        }
    );
}

int main(int argc, char **argv)
{
    Arguments Args(argc, argv);
    size_t n = Args.Get("n", size_t(1000000000L));

    Timer T0("init", 2);
    std::vector<double> u(n), v(n);

    for (size_t i=0; i<v.size(); i++)
    {
       u[i] = 1.0*i;
       v[i] = 0.0;
    }
    std::cout << T0 << std::endl;

    Timer Ts("sequentiel", 1);
    Sequentiel(u, v, 2.0);
    std::cout << "v[5] = " << v[5] << Ts << std::endl;

    Timer T1a("parallel v1a", 1);
    Parallel_v1a(u, v, 2.0);
    std::cout << "v[5] = " << v[5] << T1a << std::endl;

    Timer T1b("parallel v1b", 1);
    Parallel_v1b(u, v, 2.0);
    std::cout << "v[5] = " << v[5] << T1b << std::endl;

    Timer T2("parallel v2", 1);
    Parallel_v2(u, v, 2.0);
    std::cout << "v[5] = " << v[5] << T2 << std::endl;

    Timer T3("parallel v3", 1);
    Parallel_v3(u, v, 2.0);
    std::cout << "v[5] = " << v[5] << T3 << std::endl;

    return 0;
}
