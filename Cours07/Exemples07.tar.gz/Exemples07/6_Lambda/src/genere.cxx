#include "genere.hxx"
#include <random>

void generePoints(std::vector<double> &p, std::vector<double> &v)
{
  size_t i, n = p.size();
  p[0] = 0.0;
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_real_distribution<> dis(0.0, 1.0);
  for (i = 1; i < n; ++i)
    p[i] = p[i-1] + dis(gen);

  double pmax = p[n-1];
  for (i=0; i<n; ++i) {
    p[i] /= pmax;
    v[i] = sin(p[i]);
  }
}
