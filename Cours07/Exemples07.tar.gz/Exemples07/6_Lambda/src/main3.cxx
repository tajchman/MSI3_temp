#include <iostream>
#include <cmath>
#include <vector>

#include "genere.hxx"
#include "arguments.hxx"

int main(int argc, char **argv)
{
  Arguments A(argc, argv);
  long n = A.Get("n", 400000000L);
  double x0 = A.Get("x0", 0.0);
  double x1 = A.Get("x1", 1.0);
  
  std::vector<double> pos(n);
  std::vector<double> values(n);
  generePoints(pos, values);

  auto I = [=] (double x)  {
    size_t i, n = pos.size();
    for (i=0; i<n; i++)
      if (pos[i] > x) break;
    if (i == 0)
      return values[0];
    if (i >= n )
      return values[n-1];
    double l = (x - pos[i-1])/(pos[i] - pos[i-1]);
    return l*values[i] + (1-l) *values[i-1];
  };

  std::cout << "(Lambda fonction)  interpolateur I(0.5) = " << I(0.5) 
            << " (valeur exacte : " << sin(0.5) << ")" << std::endl;

  return 0;
}
