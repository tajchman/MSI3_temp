#include <vector>

void generePoints(std::vector<double> &p, std::vector<double> &v);
