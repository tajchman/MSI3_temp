// pause de n microsecondes
void pause(int n);
