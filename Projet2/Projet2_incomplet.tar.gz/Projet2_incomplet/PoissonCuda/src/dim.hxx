void setDims(const int *n, 
             const double *xmin, 
             const double *dx, 
             const double *lambda);
