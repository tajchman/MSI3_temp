
double cond_ini(double x, double y, double z);
double cond_lim(double x, double y, double z);
double force(double x, double y, double z, double t);
